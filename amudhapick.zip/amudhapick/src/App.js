import React from "react";
import "./App.css";
import {connect} from "react-redux";
import Destinations from "./Destinations";
import Vacations from "./Vacations";
import Itineraries from "./Itineraries"
import {fetchJSON} from "./action/action";

class App extends React.Component{
    constructor(props){
        super(props);
        this.state={"header-Title":"Pickyourtrail Sitemap",destinations:"",themevacations:"",itinerary:""};
      
        this.themedVacationTitle = "Themed Vacations";
    }
    componentDidMount(){
            this.props.fetchJSON();
    }

    componentWillReceiveProps(props){
        console.log(this.props)
        this.setState({destinations:props.data.destinations,itinerary:props.data.itineraries,vacations:props.data.vacations})
        this.forceUpdate();

    }

    render(){
        console.log(this.props)
        return(<div className="main-div">
            <div className="header-title">{this.state["header-Title"]}</div  >
            
            <Destinations/>
            <Vacations/>
            <div className="div-show-pages">{this.props.data.itineraries?"Showing all "+this.props.data.itineraries.length+" Pages":null}</div>
            <Itineraries/>
        </div>)
    }
}

const mapStateToProps = (state) => {
    return {
        data:state.data
    }
}


const mapdispatchToprops=(dispatch)=>{
    return{
        fetchJSON:()=>dispatch(fetchJSON())
    }
}

export default connect(mapStateToProps,mapdispatchToprops)(App)