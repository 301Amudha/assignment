import React from "react";
import "./style.css";

import {connect} from "react-redux";

class Destinations extends React.Component{
    constructor(props){
        super(props)
        this.destinationTitle= "Destination";
    }
   
    render(){
        return(
            <div>
                <div className="destination-title">{this.destinationTitle}</div>
                <hr/>
                {
                    (this.props.data.destinations?this.props.data.destinations.map((listValue,key)=>{
                        let displayString = listValue["text"].charAt(0).toUpperCase()+listValue["text"].slice(1).substring(0,16);
                        if(listValue["text"].length > 16){
                            displayString=displayString+"..."
                        }
                            return <div key={key} className="destination-div">{displayString}</div>
                    }):null)
                }
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        data:state.data
    }
}


export default connect(mapStateToProps,null)(Destinations)