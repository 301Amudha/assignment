import React from "react";
import "./style.css";

import {connect} from "react-redux";

class Itineraries extends React.Component{
    constructor(props){
        super(props)
        this.alphabet = [];
        for (var i = 65; i <= 90; i++) {
            this.alphabet.push(String.fromCharCode(i));
        }
       
    }
   
    render(){
        return(
            <div>
               <hr/>
               <div className="ruller-div">
               <div className="search-div">{"0-9"}</div>{
                  this.alphabet.map((value)=>{
                    return <div className="search-div"><a href={"#" +value}>{value}</a></div>
                  })
               }
               </div>
               <hr/>
               <div>
                   {
                       (this.props.data.itineraries?this.props.data.itineraries.map((value,key)=>{
                           return <div className="itineraries-div" id={value["text"].substring(0,1)}>{value["text"]}</div>
                       }):null)
                   }
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        data:state.data
    }
}


export default connect(mapStateToProps,null)(Itineraries)