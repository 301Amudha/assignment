import React from "react";
import "./style.css";

import {connect} from "react-redux";

class Vacations extends React.Component{
    constructor(props){
        super(props)
        this.vacationTitle= "Themed Vacations";
    }
   
    render(){
        return(
            <div>
                <div className="vacation-title">{this.vacationTitle}</div>
                <hr/>
                {
                    (this.props.data.destinations?this.props.data.vacations.map((listValue,key)=>{
                        let displayString = listValue["text"].charAt(0).toUpperCase()+listValue["text"].slice(1).substring(0,16);
                        if(listValue["text"].length > 16){
                            displayString=displayString+"..."
                        }
                            return <div key={key} className="vacation-div">{displayString}</div>
                    }):null)
                }
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        data:state.data
    }
}


export default connect(mapStateToProps,null)(Vacations)