import {FETCH_JSON} from "../action/actionType"
function updatedatainredux(data){
    return{
        type:FETCH_JSON,
        payload:data
    }
}
export const fetchJSON=(()=>(dispatch)=>{
    fetch("./sample.json", {
        method: 'GET',
        headers: {
        "Accept": "application/json",
        'Content-Type': 'application/json'
        }}).then(response=>{
       return response.json();
    }).then((res)=>{
        /*unique destination*/
        let destinations = [];
        let destinationsOriginal = [];
        let tempdata = res.destinations;
        for(var i=0;i<tempdata.length;i++){
            if(destinations.indexOf(tempdata[i].text) == -1){
                destinations.push(tempdata[i].text);
                destinationsOriginal.push(tempdata[i])
            }
        }
        res.destinations =destinationsOriginal;

        /*unique itineraries*/
        let itineraries = [];
        let itinerariesOriginal = [];
        let tempdataitineraries = res.itineraries;
        for(var i=0;i<tempdataitineraries.length;i++){
            if(itineraries.indexOf(tempdataitineraries[i].text) == -1){
                itineraries.push(tempdataitineraries[i].text);
                itinerariesOriginal.push(tempdataitineraries[i])
            }
        }
        res.itineraries =itinerariesOriginal;

        console.log(res)
        dispatch(updatedatainredux(res));
    }).catch((error)=>{
        console.log(error)
    })
})