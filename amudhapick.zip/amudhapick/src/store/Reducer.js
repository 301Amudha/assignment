
import {FETCH_JSON} from "../action/actionType";
let initalState={data:[]};

export function Reducer(state=initalState,action){
    switch(action.type){
        case FETCH_JSON: return {...state,
                                data:action.payload 
                                }

        default:return state;
 

    }

}